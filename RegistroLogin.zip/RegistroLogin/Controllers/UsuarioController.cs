﻿using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RegistroLogin.Data;
using RegistroLogin.Filters;
using RegistroLogin.Models;
using RegistroLogin.Repositories;

namespace RegistroLogin.Controllers
{
    public class UsuarioController : Controller
    {
        private readonly WebContext _context;
        private RepositoryWeb _repo;

        public UsuarioController(WebContext context)
        {
            _context = context;
        }

        [AuthorizeUsers]
        public async Task<IActionResult> IndexAsync()
        {
            return
              View(await _context._usuarios.ToListAsync());
        }

        [AuthorizeUsers(Policy = "ADMINISTRADORES")]
        public IActionResult AdminUsuarios()
        {
            List<Usuario> _usuarios = this._repo.GetUsuarios();
            return View(_usuarios);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        // GET: Usuarios/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var usuarios = await _context._usuarios
                .FirstOrDefaultAsync(m => m.UsuID == id);
            if (usuarios == null)
            {
                return NotFound();
            }

            return View(usuarios);
        }

    }
}
