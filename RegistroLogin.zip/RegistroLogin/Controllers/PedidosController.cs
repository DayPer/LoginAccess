﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RegistroLogin.Data;
using RegistroLogin.Filters;
using RegistroLogin.Models;
using RegistroLogin.Repositories;

namespace RegistroLogin.Controllers
{
    public class PedidosController : Controller
    {
        //private readonly WebContext _context;

        //public PedidosController(WebContext context)
        //{
        //    _context = context;
        //}

        private readonly WebContext _context;
        private RepositoryWeb _repo;


        public PedidosController(WebContext context)
        {
            _context = context;
        }

        [AuthorizeUsers]

        public async Task<IActionResult> Index()
        {
            return View(await _context._pedidos.ToListAsync());
        }

        // GET: pedidosEF/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pedidos = await _context._pedidos
                .FirstOrDefaultAsync(m => m.PedID == id);
            if (pedidos == null)
            {
                return NotFound();
            }

            return View(pedidos);
        }

        // GET: pedidosEF/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: pedidosEF/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
       
        public async Task<IActionResult> Create([Bind("PedID,PedUsu,pedPro,pedVrUnit,PedCant,PedSubtot,PedIVA,PedTotal")] pedidos pedidos)
        {
            if (ModelState.IsValid)
            {
                _context.Add(pedidos);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(pedidos);
        }

        // GET: pedidosEF/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pedidos = await _context._pedidos.FindAsync(id);
            if (pedidos == null)
            {
                return NotFound();
            }
            return View(pedidos);
        }

        // POST: pedidosEF/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]

        public async Task<IActionResult> Edit(int id, [Bind("PedID,PedUsu,pedPro,pedVrUnit,PedCant,PedSubtot,PedIVA,PedTotal")] pedidos pedidos)
        {
            if (id != pedidos.PedID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(pedidos);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!pedidosExists(pedidos.PedID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(pedidos);
        }

        // GET: pedidosEF/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var pedidos = await _context._pedidos
                .FirstOrDefaultAsync(m => m.PedID == id);
            if (pedidos == null)
            {
                return NotFound();
            }

            return View(pedidos);
        }

        // POST: pedidosEF/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var pedidos = await _context._pedidos.FindAsync(id);
            _context._pedidos.Remove(pedidos);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool pedidosExists(int id)
        {
            return _context._pedidos.Any(e => e.PedID == id);
        }
    }
}
