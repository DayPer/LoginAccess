﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RegistroLogin.Data;
using RegistroLogin.Repositories;
using RegistroLogin.Filters;
using RegistroLogin.Models;

namespace Api_Project.Controllers
{
    public class ProductosController : Controller
    {
        //private readonly EntityFrameworkContext _context;

        //public ProductosController(EntityFrameworkContext context)
        //{
        //    _context = context;
        //}

        private readonly WebContext _context;
        private RepositoryWeb _repo;

        public ProductosController(WebContext context)
        {
            _context = context;
        }

        [AuthorizeUsers]

        // GET: productosEF
        public async Task<IActionResult> Index()
        {
            return View(await _context._productos.ToListAsync());
        }

        // GET: productosEF/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var productos = await _context._productos
                .FirstOrDefaultAsync(m => m.ProID == id);
            if (productos == null)
            {
                return NotFound();
            }

            return View(productos);
        }

        // GET: productosEF/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: productosEF/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ProID,ProDesc,ProValor")] productos productos)
        {
            if (ModelState.IsValid)
            {
                _context.Add(productos);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(productos);
        }

        // GET: productosEF/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var productos = await _context._productos.FindAsync(id);
            if (productos == null)
            {
                return NotFound();
            }
            return View(productos);
        }

        // POST: productosEF/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ProID,ProDesc,ProValor")] productos productos)
        {
            if (id != productos.ProID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(productos);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!productosExists(productos.ProID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(productos);
        }

        // GET: productosEF/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var productos = await _context._productos
                .FirstOrDefaultAsync(m => m.ProID == id);
            if (productos == null)
            {
                return NotFound();
            }

            return View(productos);
        }

        // POST: productosEF/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var productos = await _context._productos.FindAsync(id);
            _context._productos.Remove(productos);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool productosExists(int id)
        {
            return _context._productos.Any(e => e.ProID == id);
        }
    }
}
