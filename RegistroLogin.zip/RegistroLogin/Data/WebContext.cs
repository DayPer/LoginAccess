﻿using Microsoft.EntityFrameworkCore;
using RegistroLogin.Models;

namespace RegistroLogin.Data
{
    public class WebContext: DbContext
    {
        public WebContext(DbContextOptions<WebContext> options) : base(options) { }

 
        public DbSet<Usuario> _usuarios { get; set; }

        public DbSet<pedidos> _pedidos { get; set; }


        public DbSet<productos> _productos { get; set; }

    }
}
