﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace RegistroLogin.Models
{
    [Table("Pedidos")]
    public class pedidosDet 
    {
        [Key]
        [Column("PedID")]
        public int PedID { get; set; }
        [Key]
        [Column("PedUsu")]
        public string PedUsu { get; set; }

        [Column("pedPro")]
        public int pedPro { get; set; }

        [Column("pedVrUnit")]
        public Decimal pedVrUnit { get; set; }

        [Column("PedCant")]
        public int PedCant { get; set; }

        [Column("PedSubtot")]
        public Decimal PedSubtot { get; set; }

        [Column("PedIVA")]
        public Decimal PedIVA { get; set; }

        [Column("PedTotal")]
        public Decimal PedTotal { get; set; }

    }

}
