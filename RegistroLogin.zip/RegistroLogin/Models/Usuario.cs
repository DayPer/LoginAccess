﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace RegistroLogin.Models
{
    [Table("Usuarios")]
    public class Usuario
    {
        [Key]
        [Column("UsuID")]
        public int UsuID { get; set; }

        [Column("UsuPass")]
        public byte[] UsuPass { get; set; }

        [Column("Salt")]
        public string Salt { get; set; }

        [Column("UsuNombre")]
        public string UsuNombre { get; set; }

        [Column("TIPO")]
        public string Tipo { get; set; }
    }
}
