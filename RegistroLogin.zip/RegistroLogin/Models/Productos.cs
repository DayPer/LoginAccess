﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace RegistroLogin.Models
{
    [Table("Productos")]
    public class productos
    {
        [Key]
        [Column("ProID")]
        public int ProID { get; set; }

        [Column("ProDesc")]
        public string ProDesc { get; set; }

        [Column("ProValor")]
        public Decimal ProValor { get; set; }


    }

}
