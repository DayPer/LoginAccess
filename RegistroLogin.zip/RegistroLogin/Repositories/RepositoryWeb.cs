﻿using RegistroLogin.Data;
using RegistroLogin.Helpers;
using RegistroLogin.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RegistroLogin.Repositories
{
    public class RepositoryWeb
    {
        private WebContext context;

        public RepositoryWeb(WebContext context)
        {
            this.context = context;
        }

        private int GetMaxIdUsuario()
        {
            if (this.context._usuarios.Count() == 0)
            {
                return 1;
            }
            else
            {
                return this.context._usuarios.Max(z => z.UsuID) + 1;
            }
        }

        private bool ExisteUsuario(string UsuNombre)
        {
            var consulta = from datos in this.context._usuarios
                           where datos.UsuNombre == UsuNombre
                           select datos;
            if(consulta.Count() > 0 )
            {
                //El UsuNombre existe en la base de datos
                return true;
            }
            else
            {
                return false;
            }
        }

        public bool RegistrarUsuario(string UsuNombre, string UsuPass, string tipo)
        {
            bool ExisteNombre = this.ExisteUsuario(UsuNombre);
            if (ExisteNombre)
            {
                return false;
            }
            else
            {
                int UsuID = this.GetMaxIdUsuario();
                Usuario _usuario = new Usuario();
                _usuario.UsuID = UsuID;
                _usuario.UsuNombre = UsuNombre;
                _usuario.Tipo = tipo;
                //GENERAMOS UN SALT ALEATORIO PARA CADA USUARIO
                _usuario.Salt = HelperCryptography.GenerateSalt();
                //GENERAMOS SU PASSWORD CON EL SALT
                _usuario.UsuPass = HelperCryptography.EncriptarPassword(UsuPass, _usuario.Salt);
                this.context._usuarios.Add(_usuario);
                this.context.SaveChanges();

                return true;
            }
            
        }

        public Usuario LogInUsuario(string UsuNombre, string UsuPass)
        {
            Usuario _usuario = this.context._usuarios.SingleOrDefault(x => x.UsuNombre == UsuNombre);
            if (_usuario == null)
            {
                return null;
            }
            else
            {
                //Debemos comparar con la base de datos el password haciendo de nuevo el cifrado con cada salt de usuario
                byte[] passUsuario = _usuario.UsuPass;
                string salt =_usuario.Salt;
                //Ciframos de nuevo para comparar
                byte[] temporal = HelperCryptography.EncriptarPassword(UsuPass, salt);

                //Comparamos los arrays para comprobar si el cifrado es el mismo
                bool respuesta = HelperCryptography.compareArrays(passUsuario, temporal);
                if(respuesta == true)
                {
                    return _usuario;
                }
                else
                {
                    //Contraseña incorrecta
                    return null;
                }
            }
        }

        public List<Usuario> GetUsuarios()
        {
            var consulta = from datos in this.context._usuarios
                           select datos;
            return consulta.ToList();
        }
    }
}
